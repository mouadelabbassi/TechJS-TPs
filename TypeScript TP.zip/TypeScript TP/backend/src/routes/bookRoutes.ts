import express from "express";
import {
    createBook,
    deleteBook,
    getBooks,
    getBookStats,
    updateBook
} from "../controllers/bookController";

const router = express.Router();

router.get("/", getBooks);
router.get("/stats", getBookStats);
router.post("/", createBook);
router.put("/:id", updateBook);
router.delete("/:id", deleteBook);

export default router;