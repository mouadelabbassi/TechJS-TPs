import { BookFormat, BookModel, BookStatus } from "../models/BookModel";

interface BookConstructorParams {
    id?: string;
    title: string;
    author: string;
    numberOfPages: number;
    status: BookStatus;
    price: number;
    pagesRead?: number;
    format: BookFormat;
    suggestedBy: string;
}

export class Book {
    public id?: string;
    public title: string;
    public author: string;
    public numberOfPages: number;
    public status: BookStatus;
    public price: number;
    public pagesRead: number;
    public format: BookFormat;
    public suggestedBy: string;
    public finished: boolean;

    constructor(data: BookConstructorParams) {
        this.id = data.id;
        this.title = data.title;
        this.author = data.author;
        this.numberOfPages = data.numberOfPages;
        this.status = data.status;
        this.price = data.price;
        this.pagesRead = data.pagesRead ?? 0;
        this.format = data.format;
        this.suggestedBy = data.suggestedBy;
        this.finished = false;

        this.synchronizeReadingState();
    }

    private synchronizeReadingState(): void {
        if (this.numberOfPages <= 0) {
            throw new Error("Number of pages must be greater than 0");
        }

        if (this.pagesRead < 0) {
            throw new Error("Pages read cannot be negative");
        }

        if (this.pagesRead > this.numberOfPages) {
            throw new Error("Pages read cannot be greater than number of pages");
        }

        if (this.status === BookStatus.Read) {
            this.pagesRead = this.numberOfPages;
            this.finished = true;
            return;
        }

        if (this.pagesRead === this.numberOfPages) {
            this.status = BookStatus.Read;
            this.finished = true;
            return;
        }

        this.finished = false;
    }

    public currentlyAt(pages: number): number {
        this.pagesRead = pages;
        this.synchronizeReadingState();

        return this.readingPercentage;
    }

    public get readingPercentage(): number {
        return Math.round((this.pagesRead / this.numberOfPages) * 100);
    }

    public async deleteBook(): Promise<boolean> {
        if (!this.id) {
            throw new Error("Cannot delete a book without an id");
        }

        const deletedBook = await BookModel.findByIdAndDelete(this.id);

        return deletedBook !== null;
    }
}