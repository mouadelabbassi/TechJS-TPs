import mongoose, { Document, Schema } from "mongoose";

export enum BookStatus {
    Read = "Read",
    ReRead = "Re-read",
    DNF = "DNF",
    CurrentlyReading = "Currently reading",
    ReturnedUnread = "Returned Unread",
    WantToRead = "Want to read"
}

export enum BookFormat {
    Print = "Print",
    PDF = "PDF",
    Ebook = "Ebook",
    AudioBook = "AudioBook"
}

export interface IBook extends Document {
    title: string;
    author: string;
    numberOfPages: number;
    status: BookStatus;
    price: number;
    pagesRead: number;
    format: BookFormat;
    suggestedBy: string;
    finished: boolean;
    createdAt: Date;
    updatedAt: Date;
}

const BookSchema = new Schema<IBook>(
    {
        title: {
            type: String,
            required: [true, "Title is required"],
            trim: true
        },

        author: {
            type: String,
            required: [true, "Author is required"],
            trim: true
        },

        numberOfPages: {
            type: Number,
            required: [true, "Number of pages is required"],
            min: [1, "Number of pages must be greater than 0"]
        },

        status: {
            type: String,
            enum: Object.values(BookStatus),
            required: [true, "Status is required"]
        },

        price: {
            type: Number,
            required: [true, "Price is required"],
            min: [0, "Price must be greater than or equal to 0"]
        },

        pagesRead: {
            type: Number,
            required: [true, "Pages read is required"],
            min: [0, "Pages read must be greater than or equal to 0"]
        },

        format: {
            type: String,
            enum: Object.values(BookFormat),
            required: [true, "Format is required"]
        },

        suggestedBy: {
            type: String,
            required: [true, "Suggested by is required"],
            trim: true
        },

        finished: {
            type: Boolean,
            default: false
        }
    },
    {
        timestamps: true
    }
);

BookSchema.pre("validate", function (next) {
    if (this.pagesRead > this.numberOfPages) {
        next(new Error("Pages read must be less than or equal to number of pages"));
        return;
    }

    if (this.status === BookStatus.Read) {
        this.pagesRead = this.numberOfPages;
        this.finished = true;
        next();
        return;
    }

    if (this.pagesRead === this.numberOfPages) {
        this.status = BookStatus.Read;
        this.finished = true;
        next();
        return;
    }

    this.finished = false;

    next();
});

export const BookModel = mongoose.model<IBook>("Book", BookSchema);