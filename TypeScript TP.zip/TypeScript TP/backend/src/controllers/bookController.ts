import { Request, Response } from "express";
import mongoose from "mongoose";
import { Book } from "../classes/Book";
import { BookFormat, BookModel, BookStatus, IBook } from "../models/BookModel";

const calculateReadingPercentage = (pagesRead: number, numberOfPages: number): number => {
    return Math.round((pagesRead / numberOfPages) * 100);
};

const formatBookResponse = (book: IBook) => {
    return {
        id: book._id,
        title: book.title,
        author: book.author,
        numberOfPages: book.numberOfPages,
        status: book.status,
        price: book.price,
        pagesRead: book.pagesRead,
        format: book.format,
        suggestedBy: book.suggestedBy,
        finished: book.finished,
        readingPercentage: calculateReadingPercentage(book.pagesRead, book.numberOfPages),
        createdAt: book.createdAt,
        updatedAt: book.updatedAt
    };
};

const isValidEnumValue = <T extends object>(enumObject: T, value: unknown): boolean => {
    return Object.values(enumObject).includes(value as T[keyof T]);
};

export const getBooks = async (_req: Request, res: Response): Promise<void> => {
    try {
        const books = await BookModel.find().sort({ createdAt: -1 });

        res.status(200).json({
            success: true,
            count: books.length,
            data: books.map(formatBookResponse)
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Failed to get books",
            error: error instanceof Error ? error.message : "Unknown error"
        });
    }
};

export const createBook = async (req: Request, res: Response): Promise<void> => {
    try {
        const {
            title,
            author,
            numberOfPages,
            status,
            price,
            pagesRead,
            format,
            suggestedBy
        } = req.body;

        if (!isValidEnumValue(BookStatus, status)) {
            res.status(400).json({
                success: false,
                message: "Invalid status value"
            });
            return;
        }

        if (!isValidEnumValue(BookFormat, format)) {
            res.status(400).json({
                success: false,
                message: "Invalid format value"
            });
            return;
        }

        const book = new Book({
            title,
            author,
            numberOfPages: Number(numberOfPages),
            status,
            price: Number(price),
            pagesRead: Number(pagesRead),
            format,
            suggestedBy
        });

        const createdBook = await BookModel.create({
            title: book.title,
            author: book.author,
            numberOfPages: book.numberOfPages,
            status: book.status,
            price: book.price,
            pagesRead: book.pagesRead,
            format: book.format,
            suggestedBy: book.suggestedBy,
            finished: book.finished
        });

        res.status(201).json({
            success: true,
            message: "Book created successfully",
            data: formatBookResponse(createdBook)
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: "Failed to create book",
            error: error instanceof Error ? error.message : "Unknown error"
        });
    }
};

export const updateBook = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;

        if (!mongoose.Types.ObjectId.isValid(id)) {
            res.status(400).json({
                success: false,
                message: "Invalid book id"
            });
            return;
        }

        const existingBook = await BookModel.findById(id);

        if (!existingBook) {
            res.status(404).json({
                success: false,
                message: "Book not found"
            });
            return;
        }

        const updatedData = {
            title: req.body.title ?? existingBook.title,
            author: req.body.author ?? existingBook.author,
            numberOfPages: req.body.numberOfPages !== undefined
                ? Number(req.body.numberOfPages)
                : existingBook.numberOfPages,
            status: req.body.status ?? existingBook.status,
            price: req.body.price !== undefined
                ? Number(req.body.price)
                : existingBook.price,
            pagesRead: req.body.pagesRead !== undefined
                ? Number(req.body.pagesRead)
                : existingBook.pagesRead,
            format: req.body.format ?? existingBook.format,
            suggestedBy: req.body.suggestedBy ?? existingBook.suggestedBy
        };

        if (!isValidEnumValue(BookStatus, updatedData.status)) {
            res.status(400).json({
                success: false,
                message: "Invalid status value"
            });
            return;
        }

        if (!isValidEnumValue(BookFormat, updatedData.format)) {
            res.status(400).json({
                success: false,
                message: "Invalid format value"
            });
            return;
        }

        const book = new Book({
            id,
            ...updatedData
        });

        const updatedBook = await BookModel.findByIdAndUpdate(
            id,
            {
                title: book.title,
                author: book.author,
                numberOfPages: book.numberOfPages,
                status: book.status,
                price: book.price,
                pagesRead: book.pagesRead,
                format: book.format,
                suggestedBy: book.suggestedBy,
                finished: book.finished
            },
            {
                new: true,
                runValidators: true
            }
        );

        if (!updatedBook) {
            res.status(404).json({
                success: false,
                message: "Book not found"
            });
            return;
        }

        res.status(200).json({
            success: true,
            message: "Book updated successfully",
            data: formatBookResponse(updatedBook)
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: "Failed to update book",
            error: error instanceof Error ? error.message : "Unknown error"
        });
    }
};

export const deleteBook = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;

        if (!mongoose.Types.ObjectId.isValid(id)) {
            res.status(400).json({
                success: false,
                message: "Invalid book id"
            });
            return;
        }

        const existingBook = await BookModel.findById(id);

        if (!existingBook) {
            res.status(404).json({
                success: false,
                message: "Book not found"
            });
            return;
        }

        const book = new Book({
            id,
            title: existingBook.title,
            author: existingBook.author,
            numberOfPages: existingBook.numberOfPages,
            status: existingBook.status,
            price: existingBook.price,
            pagesRead: existingBook.pagesRead,
            format: existingBook.format,
            suggestedBy: existingBook.suggestedBy
        });

        await book.deleteBook();

        res.status(200).json({
            success: true,
            message: "Book deleted successfully"
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Failed to delete book",
            error: error instanceof Error ? error.message : "Unknown error"
        });
    }
};

export const getBookStats = async (_req: Request, res: Response): Promise<void> => {
    try {
        const books = await BookModel.find();

        const totalBooksRead = books.filter((book) => book.finished).length;

        const totalPagesRead = books.reduce((total, book) => {
            return total + book.pagesRead;
        }, 0);

        res.status(200).json({
            success: true,
            data: {
                totalBooksRead,
                totalPagesRead,
                totalBooks: books.length
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Failed to get statistics",
            error: error instanceof Error ? error.message : "Unknown error"
        });
    }
};