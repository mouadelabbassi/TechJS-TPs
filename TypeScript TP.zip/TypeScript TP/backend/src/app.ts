import cors from "cors";
import express, { Request, Response } from "express";
import bookRoutes from "./routes/bookRoutes";

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (_req: Request, res: Response) => {
    res.status(200).json({
        message: "Book Reading Tracker API is running"
    });
});

app.use("/api/books", bookRoutes);

app.use((_req: Request, res: Response) => {
    res.status(404).json({
        success: false,
        message: "Route not found"
    });
});

export default app;