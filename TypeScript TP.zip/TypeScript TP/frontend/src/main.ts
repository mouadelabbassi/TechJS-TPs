import "./style.css";

enum BookStatus {
    Read = "Read",
    ReRead = "Re-read",
    DNF = "DNF",
    CurrentlyReading = "Currently reading",
    ReturnedUnread = "Returned Unread",
    WantToRead = "Want to read"
}

enum BookFormat {
    Print = "Print",
    PDF = "PDF",
    Ebook = "Ebook",
    AudioBook = "AudioBook"
}

interface Book {
    id: string;
    title: string;
    author: string;
    numberOfPages: number;
    status: BookStatus;
    price: number;
    pagesRead: number;
    format: BookFormat;
    suggestedBy: string;
    finished: boolean;
    readingPercentage: number;
}

interface BookStats {
    totalBooks: number;
    totalBooksRead: number;
    totalPagesRead: number;
}

interface ApiResponse<T> {
    success: boolean;
    message?: string;
    count?: number;
    data: T;
    error?: string;
}

const API_URL = "http://localhost:5000/api/books";

const bookForm = document.querySelector<HTMLFormElement>("#book-form");
const formMessage = document.querySelector<HTMLParagraphElement>("#form-message");
const booksList = document.querySelector<HTMLDivElement>("#books-list");
const refreshButton = document.querySelector<HTMLButtonElement>("#refresh-button");

const totalBooksElement = document.querySelector<HTMLParagraphElement>("#total-books");
const totalBooksReadElement = document.querySelector<HTMLParagraphElement>("#total-books-read");
const totalPagesReadElement = document.querySelector<HTMLParagraphElement>("#total-pages-read");

const statusOptions = Object.values(BookStatus);
const formatOptions = Object.values(BookFormat);

const showMessage = (message: string, type: "success" | "error"): void => {
    if (!formMessage) return;

    formMessage.textContent = message;
    formMessage.className = type === "success"
        ? "text-sm text-green-600"
        : "text-sm text-red-600";
};

const validateBookForm = (
    numberOfPages: number,
    pagesRead: number,
    price: number
): string | null => {
    if (numberOfPages <= 0) {
        return "Number of pages must be greater than 0.";
    }

    if (pagesRead < 0 || pagesRead > numberOfPages) {
        return "Pages read must be between 0 and number of pages.";
    }

    if (price < 0) {
        return "Price must be greater than or equal to 0.";
    }

    return null;
};

const fetchBooks = async (): Promise<Book[]> => {
    const response = await fetch(API_URL);

    if (!response.ok) {
        throw new Error("Failed to fetch books");
    }

    const result: ApiResponse<Book[]> = await response.json();

    return result.data;
};

const fetchStats = async (): Promise<BookStats> => {
    const response = await fetch(`${API_URL}/stats`);

    if (!response.ok) {
        throw new Error("Failed to fetch statistics");
    }

    const result: ApiResponse<BookStats> = await response.json();

    return result.data;
};

const createBook = async (bookData: Omit<Book, "id" | "finished" | "readingPercentage">): Promise<void> => {
    const response = await fetch(API_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(bookData)
    });

    const result: ApiResponse<Book> = await response.json();

    if (!response.ok) {
        throw new Error(result.error || result.message || "Failed to create book");
    }
};

const updateBook = async (
    id: string,
    pagesRead: number,
    status: BookStatus
): Promise<void> => {
    const response = await fetch(`${API_URL}/${id}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            pagesRead,
            status
        })
    });

    const result: ApiResponse<Book> = await response.json();

    if (!response.ok) {
        throw new Error(result.error || result.message || "Failed to update book");
    }
};

const deleteBook = async (id: string): Promise<void> => {
    const response = await fetch(`${API_URL}/${id}`, {
        method: "DELETE"
    });

    const result: ApiResponse<null> = await response.json();

    if (!response.ok) {
        throw new Error(result.error || result.message || "Failed to delete book");
    }
};

const renderStats = (stats: BookStats): void => {
    if (totalBooksElement) totalBooksElement.textContent = String(stats.totalBooks);
    if (totalBooksReadElement) totalBooksReadElement.textContent = String(stats.totalBooksRead);
    if (totalPagesReadElement) totalPagesReadElement.textContent = String(stats.totalPagesRead);
};

const renderBooks = (books: Book[]): void => {
    if (!booksList) return;

    if (books.length === 0) {
        booksList.innerHTML = `
      <div class="rounded-xl border border-dashed border-slate-300 p-6 text-center text-slate-500">
        No books found. Add your first book using the form.
      </div>
    `;
        return;
    }

    booksList.innerHTML = books
        .map((book) => {
            const statusSelect = statusOptions
                .map((status) => {
                    const selected = status === book.status ? "selected" : "";

                    return `<option value="${status}" ${selected}>${status}</option>`;
                })
                .join("");

            return `
        <article class="rounded-xl border border-slate-200 p-5">
          <div class="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
            <div>
              <h3 class="text-lg font-bold text-slate-900">${book.title}</h3>
              <p class="text-sm text-slate-500">By ${book.author}</p>
              <p class="mt-2 text-sm text-slate-600">
                Format: <span class="font-medium">${book.format}</span> |
                Price: <span class="font-medium">${book.price} MAD</span> |
                Suggested by: <span class="font-medium">${book.suggestedBy}</span>
              </p>
              <p class="mt-1 text-sm text-slate-600">
                Finished:
                <span class="font-semibold ${book.finished ? "text-green-600" : "text-orange-600"}">
                  ${book.finished ? "Yes" : "No"}
                </span>
              </p>
            </div>

            <button
              class="delete-button rounded-lg bg-red-600 px-3 py-2 text-sm font-semibold text-white hover:bg-red-500"
              data-id="${book.id}"
            >
              Delete
            </button>
          </div>

          <div class="mt-4">
            <div class="mb-1 flex justify-between text-sm">
              <span>${book.pagesRead} / ${book.numberOfPages} pages</span>
              <span class="font-semibold">${book.readingPercentage}%</span>
            </div>

            <div class="h-3 overflow-hidden rounded-full bg-slate-200">
              <div
                class="h-full rounded-full bg-slate-900"
                style="width: ${book.readingPercentage}%"
              ></div>
            </div>
          </div>

          <div class="mt-4 grid gap-3 md:grid-cols-3">
            <div>
              <label class="block text-sm font-medium">Update pages read</label>
              <input
                type="number"
                min="0"
                max="${book.numberOfPages}"
                value="${book.pagesRead}"
                class="pages-read-input mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
                data-id="${book.id}"
              />
            </div>

            <div>
              <label class="block text-sm font-medium">Update status</label>
              <select
                class="status-select mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
                data-id="${book.id}"
              >
                ${statusSelect}
              </select>
            </div>

            <div class="flex items-end">
              <button
                class="update-button w-full rounded-lg bg-slate-900 px-3 py-2 text-sm font-semibold text-white hover:bg-slate-700"
                data-id="${book.id}"
                data-number-of-pages="${book.numberOfPages}"
              >
                Update
              </button>
            </div>
          </div>
        </article>
      `;
        })
        .join("");
};

const loadPageData = async (): Promise<void> => {
    try {
        const [books, stats] = await Promise.all([
            fetchBooks(),
            fetchStats()
        ]);

        renderBooks(books);
        renderStats(stats);
    } catch (error) {
        if (booksList) {
            booksList.innerHTML = `
        <div class="rounded-xl border border-red-300 bg-red-50 p-4 text-red-700">
          ${error instanceof Error ? error.message : "Something went wrong"}
        </div>
      `;
        }
    }
};

bookForm?.addEventListener("submit", async (event) => {
    event.preventDefault();

    const formData = new FormData(bookForm);

    const numberOfPages = Number(formData.get("numberOfPages"));
    const pagesRead = Number(formData.get("pagesRead"));
    const price = Number(formData.get("price"));

    const validationError = validateBookForm(numberOfPages, pagesRead, price);

    if (validationError) {
        showMessage(validationError, "error");
        return;
    }

    const bookData = {
        title: String(formData.get("title")),
        author: String(formData.get("author")),
        numberOfPages,
        status: formData.get("status") as BookStatus,
        price,
        pagesRead,
        format: formData.get("format") as BookFormat,
        suggestedBy: String(formData.get("suggestedBy"))
    };

    try {
        await createBook(bookData);
        bookForm.reset();

        const pagesReadInput = document.querySelector<HTMLInputElement>("#pagesRead");
        if (pagesReadInput) pagesReadInput.value = "0";

        showMessage("Book created successfully.", "success");

        await loadPageData();
    } catch (error) {
        showMessage(
            error instanceof Error ? error.message : "Failed to create book.",
            "error"
        );
    }
});

booksList?.addEventListener("click", async (event) => {
    const target = event.target as HTMLElement;

    if (target.classList.contains("delete-button")) {
        const id = target.dataset.id;

        if (!id) return;

        try {
            await deleteBook(id);
            await loadPageData();
        } catch (error) {
            alert(error instanceof Error ? error.message : "Failed to delete book.");
        }
    }

    if (target.classList.contains("update-button")) {
        const id = target.dataset.id;
        const numberOfPages = Number(target.dataset.numberOfPages);

        if (!id) return;

        const pagesInput = document.querySelector<HTMLInputElement>(
            `.pages-read-input[data-id="${id}"]`
        );

        const statusSelect = document.querySelector<HTMLSelectElement>(
            `.status-select[data-id="${id}"]`
        );

        if (!pagesInput || !statusSelect) return;

        let pagesRead = Number(pagesInput.value);
        const status = statusSelect.value as BookStatus;

        if (status === BookStatus.Read) {
            pagesRead = numberOfPages;
        }

        const validationError = validateBookForm(numberOfPages, pagesRead, 0);

        if (validationError) {
            alert(validationError);
            return;
        }

        try {
            await updateBook(id, pagesRead, status);
            await loadPageData();
        } catch (error) {
            alert(error instanceof Error ? error.message : "Failed to update book.");
        }
    }
});

refreshButton?.addEventListener("click", async () => {
    await loadPageData();
});

loadPageData();