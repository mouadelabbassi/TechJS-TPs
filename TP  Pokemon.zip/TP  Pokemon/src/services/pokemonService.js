const axios = require('axios');
const Move = require('../game/Move');
const Pokemon = require('../game/Pokemon');
const { formatName, shuffleArray } = require('../utils/helpers');

const API_BASE_URL = 'https://pokeapi.co/api/v2';

const DEFAULT_POWER = 40;
const DEFAULT_ACCURACY = 100;
const DEFAULT_PP = 10;
const STARTING_HP = 300;

async function getPokemonList(limit = 20) {
    try {
        const response = await axios.get(`${API_BASE_URL}/pokemon?limit=${limit}`);
        return response.data.results;
    } catch (error) {
        throw new Error('Failed to fetch Pokémon list from PokeAPI.');
    }
}

async function getPokemonByName(name) {
    try {
        const response = await axios.get(`${API_BASE_URL}/pokemon/${name}`);
        return response.data;
    } catch (error) {
        throw new Error(`Failed to fetch Pokémon data for ${name}.`);
    }
}

async function getMoveDetails(moveUrl) {
    try {
        const response = await axios.get(moveUrl);
        const move = response.data;

        return new Move(
            formatName(move.name),
            move.power ?? DEFAULT_POWER,
            move.accuracy ?? DEFAULT_ACCURACY,
            move.pp ?? DEFAULT_PP
        );
    } catch (error) {
        return new Move('Default Move', DEFAULT_POWER, DEFAULT_ACCURACY, DEFAULT_PP);
    }
}

async function getFiveMoves(pokemonData) {
    const shuffledMoves = shuffleArray(pokemonData.moves);
    const selectedMoves = [];
    const usedMoveNames = new Set();

    for (const moveItem of shuffledMoves) {
        if (selectedMoves.length === 5) {
            break;
        }

        const move = await getMoveDetails(moveItem.move.url);

        if (!usedMoveNames.has(move.name)) {
            selectedMoves.push(move);
            usedMoveNames.add(move.name);
        }
    }

    while (selectedMoves.length < 5) {
        selectedMoves.push(
            new Move(
                `Fallback Move ${selectedMoves.length + 1}`,
                DEFAULT_POWER,
                DEFAULT_ACCURACY,
                DEFAULT_PP
            )
        );
    }

    return selectedMoves;
}

async function buildPokemonForBattle(name) {
    const pokemonData = await getPokemonByName(name);

    const moves = await getFiveMoves(pokemonData);

    const image =
        pokemonData.sprites.front_default ||
        pokemonData.sprites.other?.['official-artwork']?.front_default ||
        '';

    return new Pokemon(
        formatName(pokemonData.name),
        STARTING_HP,
        moves,
        image
    );
}

module.exports = {
    getPokemonList,
    getPokemonByName,
    buildPokemonForBattle,
    DEFAULT_POWER,
    DEFAULT_ACCURACY,
    DEFAULT_PP,
    STARTING_HP
};