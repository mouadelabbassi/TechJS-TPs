function capitalize(text) {
    if (!text) return '';
    return text.charAt(0).toUpperCase() + text.slice(1);
}

function formatName(name) {
    return capitalize(String(name).replace(/-/g, ' '));
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getRandomItem(items) {
    return items[Math.floor(Math.random() * items.length)];
}

function shuffleArray(array) {
    return [...array].sort(() => Math.random() - 0.5);
}

module.exports = {
    capitalize,
    formatName,
    randomInt,
    getRandomItem,
    shuffleArray
};