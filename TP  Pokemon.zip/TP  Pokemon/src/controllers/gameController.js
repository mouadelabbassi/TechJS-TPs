const Game = require('../game/Game');
const pokemonService = require('../services/pokemonService');
const { getRandomItem } = require('../utils/helpers');

const games = new Map();

function getCurrentGame(req) {
    return games.get(req.sessionID);
}

function saveCurrentGame(req, game) {
    games.set(req.sessionID, game);
}

function deleteCurrentGame(req) {
    games.delete(req.sessionID);
}

async function showHome(req, res) {
    res.render('index', {
        title: 'Pokémon Mini Game'
    });
}

async function showChoosePage(req, res) {
    try {
        deleteCurrentGame(req);

        const pokemonList = await pokemonService.getPokemonList(20);

        res.render('choose', {
            title: 'Choose your Pokémon',
            pokemonList,
            error: null
        });
    } catch (error) {
        res.render('choose', {
            title: 'Choose your Pokémon',
            pokemonList: [],
            error: error.message
        });
    }
}

async function startBattle(req, res) {
    try {
        const playerPokemonName = req.body.pokemonName;

        if (!playerPokemonName) {
            return res.redirect('/choose');
        }

        const pokemonList = await pokemonService.getPokemonList(20);

        const possibleBotPokemon = pokemonList.filter(
            (pokemon) => pokemon.name !== playerPokemonName
        );

        const botPokemonName = getRandomItem(possibleBotPokemon).name;

        const playerPokemon = await pokemonService.buildPokemonForBattle(playerPokemonName);
        const botPokemon = await pokemonService.buildPokemonForBattle(botPokemonName);

        const game = new Game(playerPokemon, botPokemon);

        saveCurrentGame(req, game);

        res.redirect('/battle');
    } catch (error) {
        res.status(500).render('choose', {
            title: 'Choose your Pokémon',
            pokemonList: [],
            error: error.message
        });
    }
}

function showBattlePage(req, res) {
    const game = getCurrentGame(req);

    if (!game) {
        return res.redirect('/choose');
    }

    if (game.isGameOver()) {
        return res.redirect('/result');
    }

    res.render('battle', {
        title: 'Battle',
        game
    });
}

function attack(req, res) {
    const game = getCurrentGame(req);

    if (!game) {
        return res.redirect('/choose');
    }

    const playerMoveIndex = Number(req.body.moveIndex);

    game.playTurn(playerMoveIndex);

    saveCurrentGame(req, game);

    if (game.isGameOver()) {
        return res.redirect('/result');
    }

    res.redirect('/battle');
}

function showResultPage(req, res) {
    const game = getCurrentGame(req);

    if (!game) {
        return res.redirect('/choose');
    }

    res.render('result', {
        title: 'Result',
        game,
        winner: game.getWinner()
    });
}

module.exports = {
    showHome,
    showChoosePage,
    startBattle,
    showBattlePage,
    attack,
    showResultPage
};