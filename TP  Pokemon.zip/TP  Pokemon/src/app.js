const express = require('express');
const path = require('path');
const session = require('express-session');
const expressLayouts = require('express-ejs-layouts');
const gameRoutes = require('./routes/gameRoutes');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(expressLayouts);
app.set('layout', 'layout');

app.use(express.urlencoded({ extended: true }));

// This line allows Express to load files from public/
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use(
    session({
        secret: 'pokemon-mini-game-secret',
        resave: false,
        saveUninitialized: true
    })
);

app.use('/', gameRoutes);

app.use((req, res) => {
    res.status(404).send('Page not found');
});

app.use((error, req, res, next) => {
    console.error(error);
    res.status(500).send('Something went wrong. Please try again later.');
});

module.exports = app;