const express = require('express');
const gameController = require('../controllers/gameController');

const router = express.Router();

router.get('/', gameController.showHome);
router.get('/choose', gameController.showChoosePage);
router.post('/battle/start', gameController.startBattle);
router.get('/battle', gameController.showBattlePage);
router.post('/battle/attack', gameController.attack);
router.get('/result', gameController.showResultPage);

module.exports = router;