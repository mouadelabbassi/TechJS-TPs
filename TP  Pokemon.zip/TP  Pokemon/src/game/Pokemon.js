class Pokemon {
    constructor(name, hp, moves, image) {
        this.name = name;
        this.hp = hp;
        this.moves = moves;
        this.image = image;
    }

    receiveDamage(damage) {
        this.hp -= damage;

        if (this.hp < 0) {
            this.hp = 0;
        }
    }

    isDead() {
        return this.hp <= 0;
    }
}

module.exports = Pokemon;