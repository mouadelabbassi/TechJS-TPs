const { randomInt } = require('../utils/helpers');

class Game {
    constructor(playerPokemon, botPokemon) {
        this.playerPokemon = playerPokemon;
        this.botPokemon = botPokemon;
        this.battleLog = ['The battle has started! Both Pokémon have 300 HP.'];
    }

    botChooseMove() {
        const movesWithPP = this.botPokemon.moves.filter((move) => move.hasPP());
        const possibleMoves = movesWithPP.length > 0 ? movesWithPP : this.botPokemon.moves;
        const randomIndex = Math.floor(Math.random() * possibleMoves.length);

        return possibleMoves[randomIndex];
    }

    calculateDamage(move) {
        return move.power;
    }

    checkAccuracy(move) {
        const randomNumber = randomInt(1, 100);

        return {
            randomNumber,
            hit: randomNumber <= move.accuracy
        };
    }

    playTurn(playerMoveIndex) {
        this.battleLog = [];

        const playerMove = this.playerPokemon.moves[playerMoveIndex];
        const botMove = this.botChooseMove();

        if (!playerMove) {
            this.battleLog.push('Invalid move selected. Please choose another move.');
            return;
        }

        this.battleLog.push(`${this.playerPokemon.name} selected ${playerMove.name}.`);
        this.battleLog.push(`${this.botPokemon.name} selected ${botMove.name}.`);

        const playerHadPP = playerMove.hasPP();
        const botHadPP = botMove.hasPP();

        let playerCanAttack = playerHadPP;
        let botCanAttack = botHadPP;

        if (!playerHadPP) {
            playerCanAttack = false;
            this.battleLog.push(`${this.playerPokemon.name} cannot use ${playerMove.name} because it has 0 PP.`);
        }

        if (!botHadPP) {
            botCanAttack = false;
            this.battleLog.push(`${this.botPokemon.name} cannot use ${botMove.name} because it has 0 PP.`);
        }

        if (playerHadPP && botHadPP) {
            if (playerMove.pp < botMove.pp) {
                playerCanAttack = false;
                this.battleLog.push(`${this.playerPokemon.name}'s attack is cancelled because ${playerMove.name} has lower PP than ${botMove.name}.`);
            }

            if (botMove.pp < playerMove.pp) {
                botCanAttack = false;
                this.battleLog.push(`${this.botPokemon.name}'s attack is cancelled because ${botMove.name} has lower PP than ${playerMove.name}.`);
            }
        }

        if (playerHadPP) {
            playerMove.useMove();
            this.battleLog.push(`${playerMove.name} PP decreased to ${playerMove.pp}.`);
        }

        if (botHadPP) {
            botMove.useMove();
            this.battleLog.push(`${botMove.name} PP decreased to ${botMove.pp}.`);
        }

        if (playerCanAttack) {
            const accuracyResult = this.checkAccuracy(playerMove);

            if (accuracyResult.hit) {
                const damage = this.calculateDamage(playerMove);
                this.botPokemon.receiveDamage(damage);
                this.battleLog.push(`${this.playerPokemon.name}'s attack hit! It dealt ${damage} damage.`);
            } else {
                this.battleLog.push(`${this.playerPokemon.name}'s attack missed. Random number: ${accuracyResult.randomNumber}, accuracy: ${playerMove.accuracy}.`);
            }
        }

        if (this.botPokemon.isDead()) {
            this.battleLog.push(`${this.botPokemon.name} reached 0 HP.`);
            return;
        }

        if (botCanAttack) {
            const accuracyResult = this.checkAccuracy(botMove);

            if (accuracyResult.hit) {
                const damage = this.calculateDamage(botMove);
                this.playerPokemon.receiveDamage(damage);
                this.battleLog.push(`${this.botPokemon.name}'s attack hit! It dealt ${damage} damage.`);
            } else {
                this.battleLog.push(`${this.botPokemon.name}'s attack missed. Random number: ${accuracyResult.randomNumber}, accuracy: ${botMove.accuracy}.`);
            }
        }

        if (this.playerPokemon.isDead()) {
            this.battleLog.push(`${this.playerPokemon.name} reached 0 HP.`);
        }
    }

    isGameOver() {
        return this.playerPokemon.isDead() || this.botPokemon.isDead();
    }

    getWinner() {
        if (this.playerPokemon.isDead() && this.botPokemon.isDead()) {
            return 'draw';
        }

        if (this.botPokemon.isDead()) {
            return 'player';
        }

        if (this.playerPokemon.isDead()) {
            return 'bot';
        }

        return null;
    }
}

module.exports = Game;