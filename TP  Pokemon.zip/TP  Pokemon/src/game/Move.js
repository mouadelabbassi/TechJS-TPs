class Move {
    constructor(name, power, accuracy, pp) {
        this.name = name;
        this.power = power;
        this.accuracy = accuracy;
        this.pp = pp;
    }

    hasPP() {
        return this.pp > 0;
    }

    useMove() {
        if (this.pp > 0) {
            this.pp -= 1;
        }
    }
}

module.exports = Move;