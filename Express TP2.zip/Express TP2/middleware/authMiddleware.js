exports.ensureAuthenticated = function ensureAuthenticated(req, res, next) {
    if (req.isAuthenticated && req.isAuthenticated()) {
        return next();
    }

    res.redirect('/login?error=Please%20login%20to%20access%20the%20books%20page.');
};