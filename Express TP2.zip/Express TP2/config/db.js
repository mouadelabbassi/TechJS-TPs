const mongoose = require('mongoose');

async function connectDB() {
    try {
        const mongoURI =
            process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/tp2_auth_books';

        await mongoose.connect(mongoURI);

        console.log(`MongoDB connected: ${mongoose.connection.host}`);
    } catch (error) {
        console.error('MongoDB connection error:', error.message);
        process.exit(1);
    }
}

module.exports = connectDB;