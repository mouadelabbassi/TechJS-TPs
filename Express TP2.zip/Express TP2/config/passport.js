const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcrypt');
const User = require('../models/User');

module.exports = function configurePassport(passport) {
    passport.use(
        new LocalStrategy(
            {
                usernameField: 'email',
                passwordField: 'password',
            },
            async function verify(email, password, done) {
                try {
                    const user = await User.findOne({
                        email: email.toLowerCase().trim(),
                    });

                    if (!user) {
                        return done(null, false, {
                            message: 'No user found with this email.',
                        });
                    }

                    const passwordMatches = await bcrypt.compare(password, user.password);

                    if (!passwordMatches) {
                        return done(null, false, {
                            message: 'Incorrect password.',
                        });
                    }

                    return done(null, user);
                } catch (error) {
                    return done(error);
                }
            }
        )
    );

    passport.serializeUser(function serializeUser(user, done) {
        done(null, user.id);
    });

    passport.deserializeUser(async function deserializeUser(id, done) {
        try {
            const user = await User.findById(id).select('-password');

            if (!user) {
                return done(null, false);
            }

            done(null, user);
        } catch (error) {
            done(error);
        }
    });
};