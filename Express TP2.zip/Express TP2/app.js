require('dotenv').config();

const express = require('express');
const path = require('path');
const session = require('express-session');
const passport = require('passport');

const authRoutes = require('./routes/authRoutes');
const bookRoutes = require('./routes/bookRoutes');

require('./config/passport')(passport);

const app = express();

app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));

app.use(express.urlencoded({ extended: false }));

app.use(
    session({
        secret: process.env.SESSION_SECRET || 'temporary_secret_for_development',
        resave: false,
        saveUninitialized: false,
        cookie: {
            httpOnly: true,
            maxAge: 1000 * 60 * 60 * 2,
        },
    })
);

app.use(passport.initialize());
app.use(passport.session());

app.use(function setLocalUser(req, res, next) {
    res.locals.currentUser = req.user || null;
    next();
});

app.use('/', authRoutes);
app.use('/books', bookRoutes);

app.use(function notFoundHandler(req, res) {
    res.status(404).render('index', {
        title: 'Page not found',
        error: 'Page not found. Please use the navigation links above.',
    });
});

app.use(function errorHandler(error, req, res, next) {
    console.error(error);
    res.status(500).send('Internal Server Error');
});

module.exports = app;