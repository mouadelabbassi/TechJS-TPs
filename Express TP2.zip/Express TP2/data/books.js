const books = [
    {
        id: 1,
        title: 'Clean Code',
        author: 'Robert C. Martin',
        status: 'Available',
        pages: 464,
        format: 'Paperback',
    },
    {
        id: 2,
        title: 'Eloquent JavaScript',
        author: 'Marijn Haverbeke',
        status: 'Available',
        pages: 472,
        format: 'Digital',
    },
    {
        id: 3,
        title: 'You Don’t Know JS Yet',
        author: 'Kyle Simpson',
        status: 'Reading',
        pages: 280,
        format: 'Digital',
    },
    {
        id: 4,
        title: 'JavaScript: The Good Parts',
        author: 'Douglas Crockford',
        status: 'Available',
        pages: 176,
        format: 'Paperback',
    },
    {
        id: 5,
        title: 'Node.js Design Patterns',
        author: 'Mario Casciaro and Luciano Mammino',
        status: 'Reserved',
        pages: 664,
        format: 'Hardcover',
    },
];

module.exports = books;