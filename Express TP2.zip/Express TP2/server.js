require('dotenv').config();

const app = require('./app');
const connectDB = require('./config/db');

const PORT = process.env.PORT || 3000;

async function startServer() {
    await connectDB();

    app.listen(PORT, function serverStarted() {
        console.log(`Server running on http://localhost:${PORT}`);
    });
}

startServer();