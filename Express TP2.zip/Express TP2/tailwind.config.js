module.exports = {
    content: ['./views/**/*.pug', './controllers/**/*.js', './routes/**/*.js'],
    theme: {
        extend: {},
    },
    plugins: [],
};