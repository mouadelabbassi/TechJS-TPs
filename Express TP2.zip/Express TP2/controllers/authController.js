const bcrypt = require('bcrypt');
const passport = require('passport');
const User = require('../models/User');

exports.getHome = function getHome(req, res) {
    res.render('index', {
        title: 'Home',
        error: null,
    });
};

exports.getRegister = function getRegister(req, res) {
    if (req.isAuthenticated()) {
        return res.redirect('/books');
    }

    res.render('register', {
        title: 'Register',
        errors: [],
        formData: {
            username: '',
            email: '',
        },
    });
};

exports.registerUser = async function registerUser(req, res, next) {
    try {
        const { username, email, password, confirmPassword } = req.body;

        const cleanUsername = username ? username.trim() : '';
        const cleanEmail = email ? email.trim().toLowerCase() : '';

        const errors = [];

        if (!cleanUsername) {
            errors.push('Username is required.');
        }

        if (!cleanEmail) {
            errors.push('Email is required.');
        }

        if (!password) {
            errors.push('Password is required.');
        }

        if (password !== confirmPassword) {
            errors.push('Confirm password must match password.');
        }

        if (errors.length > 0) {
            return res.status(400).render('register', {
                title: 'Register',
                errors,
                formData: {
                    username: cleanUsername,
                    email: cleanEmail,
                },
            });
        }

        const existingUser = await User.findOne({ email: cleanEmail });

        if (existingUser) {
            return res.status(400).render('register', {
                title: 'Register',
                errors: ['Email is already registered.'],
                formData: {
                    username: cleanUsername,
                    email: cleanEmail,
                },
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const user = new User({
            username: cleanUsername,
            email: cleanEmail,
            password: hashedPassword,
        });

        await user.save();

        res.redirect('/login?success=Registration%20successful.%20You%20can%20now%20login.');
    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).render('register', {
                title: 'Register',
                errors: ['Email is already registered.'],
                formData: {
                    username: req.body.username || '',
                    email: req.body.email || '',
                },
            });
        }

        next(error);
    }
};

exports.getLogin = function getLogin(req, res) {
    if (req.isAuthenticated()) {
        return res.redirect('/books');
    }

    res.render('login', {
        title: 'Login',
        error: req.query.error || null,
        success: req.query.success || null,
        formData: {
            email: '',
        },
    });
};

exports.loginUser = function loginUser(req, res, next) {
    passport.authenticate('local', {
        successRedirect: '/books',
        failureRedirect: '/login?error=Invalid%20email%20or%20password.',
    })(req, res, next);
};

exports.logoutUser = function logoutUser(req, res, next) {
    req.logout(function logoutCallback(error) {
        if (error) {
            return next(error);
        }

        req.session.destroy(function destroySession(sessionError) {
            if (sessionError) {
                return next(sessionError);
            }

            res.clearCookie('connect.sid');
            res.redirect('/');
        });
    });
};