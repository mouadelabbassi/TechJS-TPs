const books = require('../data/books');

exports.getBooks = function getBooks(req, res) {
    res.render('books', {
        title: 'Books',
        books,
        user: req.user,
    });
};