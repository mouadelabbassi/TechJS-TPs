const express = require('express');
const bookController = require('../controllers/bookController');
const { ensureAuthenticated } = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', ensureAuthenticated, bookController.getBooks);

module.exports = router;