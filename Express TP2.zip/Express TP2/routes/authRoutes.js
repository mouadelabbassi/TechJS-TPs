const express = require('express');
const authController = require('../controllers/authController');

const router = express.Router();

router.get('/', authController.getHome);

router.get('/register', authController.getRegister);
router.post('/register', authController.registerUser);

router.get('/login', authController.getLogin);
router.post('/login', authController.loginUser);

router.post('/logout', authController.logoutUser);

module.exports = router;